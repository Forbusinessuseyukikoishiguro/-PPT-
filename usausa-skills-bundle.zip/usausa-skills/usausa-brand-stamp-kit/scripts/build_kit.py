#!/usr/bin/env python3
"""brand-kit.yaml から「スタンプ・アイコン凡例／図形見本／PC環境の前提」のPPTXを作る。
使い方: python build_kit.py brand-kit.yaml out.pptx [--template brand.pptx]
--template を渡すと、企業ブランドのテンプレ（マスター・テーマ）の上に作る。
"""
import argparse
import yaml
from lxml import etree
from pptx import Presentation
from pptx.util import Inches, Pt, Cm
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.oxml.ns import qn


def rgb(h):
    return RGBColor.from_string(h)


def pick_font(cands, avail):
    """使えるフォントを先頭から採用。該当なしなら先頭＋警告。"""
    if not avail:
        return cands[0], False
    for c in cands:
        if c in avail:
            return c, False
    return cands[0], True


def put_text(shape, s, size, color, font, bold=False, align=PP_ALIGN.CENTER):
    tf = shape.text_frame
    tf.clear()
    tf.word_wrap = True
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.alignment = align
    r = p.add_run()
    r.text = s
    r.font.size = Pt(size)
    r.font.bold = bold
    r.font.name = font
    r.font.color.rgb = rgb(color)
    rPr = r._r.get_or_add_rPr()
    for tag in ("a:ea", "a:cs"):  # 日本語フォントも明示（文字化け防止）
        el = rPr.find(qn(tag))
        if el is None:
            el = etree.SubElement(rPr, qn(tag))
        el.set("typeface", font)


def style(shape, fill, line=None, lw=None):
    if fill is None:
        shape.fill.background()
    else:
        shape.fill.solid()
        shape.fill.fore_color.rgb = rgb(fill)
    if line is None:
        shape.line.fill.background()
    else:
        shape.line.color.rgb = rgb(line)
        shape.line.width = Pt(lw or 1)
    shape.shadow.inherit = False


def poly(slide, pts, x, y, w, h, color):
    """正規化座標(0-1)の多角形を x,y,w,h の枠に描く。"""
    P = [(int(x + px * w), int(y + py * h)) for px, py in pts]
    fb = slide.shapes.build_freeform(P[0][0], P[0][1])
    fb.add_line_segments(P[1:], close=True)
    s = fb.convert_to_shape()
    style(s, color)
    return s


# 文字に頼らないアイコン（形で判別できる）
CHECK = [(.18, .52), (.30, .40), (.43, .54), (.72, .22), (.84, .34), (.43, .80)]
WEDGE_L = [(.20, .22), (.48, .50), (.20, .78), (.20, .62), (.34, .50), (.20, .38)]
WEDGE_R = [(.48, .22), (.76, .50), (.48, .78), (.48, .62), (.62, .50), (.48, .38)]


def draw_icon(slide, kind, x, y, d, bg, fg, font):
    c = slide.shapes.add_shape(MSO_SHAPE.OVAL, x, y, d, d)
    style(c, bg)
    if kind == "check":
        poly(slide, CHECK, x, y, d, d, fg)
    elif kind == "skip":
        poly(slide, WEDGE_L, x, y, d, d, fg)
        poly(slide, WEDGE_R, x, y, d, d, fg)
    else:  # ASCII 1文字なのでフォント依存が無い
        g = {"warn": "!", "stuck": "?", "info": "i"}[kind]
        put_text(c, g, int(d / 12700 * 0.62), fg, font, bold=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("yaml")
    ap.add_argument("out")
    ap.add_argument("--template")
    a = ap.parse_args()

    k = yaml.safe_load(open(a.yaml, encoding="utf-8"))
    pal, env = k["brand"]["palette"], k["env"]
    avail = env.get("fonts_available") or []
    jp, jp_warn = pick_font(k["brand"]["fonts"]["jp"], avail)
    mono, mono_warn = pick_font(k["brand"]["fonts"]["mono"], avail)

    prs = Presentation(a.template) if a.template else Presentation()
    if not a.template:
        prs.slide_width = Inches(env["slide"]["width_in"])
        prs.slide_height = Inches(env["slide"]["height_in"])
    blank = prs.slide_layouts[6]
    W, H = prs.slide_width, prs.slide_height

    def new_slide(title):
        s = prs.slides.add_slide(blank)
        s.background.fill.solid()
        s.background.fill.fore_color.rgb = rgb(pal["bg"])
        t = s.shapes.add_textbox(Inches(.6), Inches(.35), W - Inches(1.2), Inches(.9))
        put_text(t, title, 28, pal["primary"], jp, True, PP_ALIGN.LEFT)
        return s

    # 1: マークの意味（資料に入れる「アイコン説明ページ」）。環境限定スタンプはOSで絞る
    s = new_slide("このマークの意味（見方）")
    stamps = [st for st in k["stamps"] if "only" not in st or env["os"] in st["only"]]
    y = Inches(1.5)
    for st in stamps:
        pill = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(.7), y, Inches(3.6), Inches(.56))
        pill.adjustments[0] = .5
        style(pill, pal[st["fill"]])
        put_text(pill, st["label"], 14, pal[st["text"]], jp, True)
        pill.text_frame.margin_left = Inches(.55)
        draw_icon(s, st["icon"], Inches(.78), y + Inches(.06), Inches(.44), pal[st["text"]], pal[st["fill"]], jp)
        m = s.shapes.add_textbox(Inches(4.6), y, W - Inches(5.2), Inches(.56))
        put_text(m, st["meaning"], 16, pal["text"], jp, False, PP_ALIGN.LEFT)
        y += Inches(.78)
    n = s.shapes.add_textbox(Inches(.7), H - Inches(1.2), W - Inches(1.4), Inches(.7))
    put_text(n, "迷ったら：確認コマンドの結果が資料と違うときは、スキップせずに手順を実施してください。",
             14, pal["muted"], jp, False, PP_ALIGN.LEFT)

    # 2: 図形見本
    s = new_slide("図形の使い方（ブランド色の見本）")
    sh = k["shapes"]
    rb = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(.8), Inches(1.7), Inches(4.4), Inches(2.4))
    style(rb, None, pal[sh["redbox"]["line"]], sh["redbox"]["width_pt"])
    cap = s.shapes.add_textbox(Inches(.8), Inches(4.2), Inches(4.4), Inches(.5))
    put_text(cap, "赤枠：スクショの見る場所", 14, pal["text"], jp)
    d = Cm(sh["step_badge"]["diameter_cm"])
    b = s.shapes.add_shape(MSO_SHAPE.OVAL, Inches(6), Inches(1.8), d, d)
    style(b, pal[sh["step_badge"]["fill"]])
    put_text(b, "1", 16, pal[sh["step_badge"]["text"]], jp, True)
    cb = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(7.4), Inches(1.7), Inches(5), Inches(1.1))
    style(cb, pal[sh["callout"]["fill"]], pal[sh["callout"]["line"]], sh["callout"]["width_pt"])
    put_text(cb, k["notes"]["success"].format(expected="Docker version 〜"), 14, pal["text"], jp)
    cm_ = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(6), Inches(3.3), Inches(6.4), Inches(.8))
    style(cm_, sh["command_box"]["fill"], pal[sh["command_box"]["line"]], 1)
    put_text(cm_, "docker --version", 18, pal["text"], mono, False, PP_ALIGN.LEFT)
    cm_.text_frame.margin_left = Inches(.25)

    # 3: PC環境の前提
    s = new_slide("この資料の前提（あなたのPC環境）")
    rows = [
        ("OS", env["os"]), ("シェル", env["shell"]), ("Office", env["office"]),
        ("日本語フォント", jp + ("（PCに無い可能性：[要確認]）" if jp_warn else "")),
        ("コマンド用フォント", mono + ("（PCに無い可能性：[要確認]）" if mono_warn else "")),
    ]
    y = Inches(1.6)
    for lab, val in rows:
        l = s.shapes.add_textbox(Inches(.8), y, Inches(3), Inches(.6))
        put_text(l, lab, 16, pal["muted"], jp, True, PP_ALIGN.LEFT)
        v = s.shapes.add_textbox(Inches(3.9), y, Inches(8.6), Inches(.6))
        put_text(v, val, 18, pal["text"], jp, False, PP_ALIGN.LEFT)
        y += Inches(.8)

    prs.save(a.out)
    print("saved", a.out, "| jp:", jp, "[要確認]" if jp_warn else "", "| mono:", mono, "[要確認]" if mono_warn else "")


if __name__ == "__main__":
    main()
